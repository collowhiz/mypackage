#my package
This package was created as an example of how to publish your own Python Package.
#How to install
...
make sure you have installed the anaconda distribution data science platform open anaconda prompt then run the command git+http.... the url given in the github repository.